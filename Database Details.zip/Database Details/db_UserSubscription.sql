-- MySQL dump 10.13  Distrib 5.7.12, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `UserSubscription`
--

DROP TABLE IF EXISTS `UserSubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserSubscription` (
  `FullName` varchar(55) DEFAULT NULL,
  `Length` varchar(55) DEFAULT NULL,
  `Subscription_Plan` varchar(55) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `PhoneNumber` varchar(55) DEFAULT NULL,
  `StartDate` varchar(55) DEFAULT NULL,
  `EndDate` varchar(55) DEFAULT NULL,
  `Top_Subscription` tinyint(1) DEFAULT NULL,
  `IconUrl` varchar(55) DEFAULT NULL,
  `CreditCards` varchar(100) DEFAULT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Subscription_Name` varchar(100) DEFAULT NULL,
  `Subscription_Url` varchar(100) DEFAULT NULL,
  `deleteBool` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserSubscription`
--

LOCK TABLES `UserSubscription` WRITE;
/*!40000 ALTER TABLE `UserSubscription` DISABLE KEYS */;
INSERT INTO `UserSubscription` VALUES ('Tanushree','Weekly','Plan 1',7.99,'4697896814',' 08-24-2016','08-22-2017',1,'www.msn.com',NULL,1,NULL,NULL,1),('Tulika','weekly,plan1','undefined',8.99,'7896813425','08-24-2016','08-29-2016',1,'ww.google.com','456',67,'verizonweekly','www.yahoo.com',0);
/*!40000 ALTER TABLE `UserSubscription` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-03  9:28:16
