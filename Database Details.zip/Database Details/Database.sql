CREATE DATABASE `db`;
use db;

CREATE TABLE TopSubscription(
  ID int(11) NOT NULL AUTO_INCREMENT,
  Subscription_Name varchar(55) DEFAULT NULL,
  Subscription_length varchar(55) DEFAULT NULL,
  Subscription_Plan1 varchar(55) DEFAULT NULL,
  Price1 double DEFAULT NULL,
  Subscription_Plan2 varchar(55) DEFAULT NULL,
  Price2 double DEFAULT NULL,
  Subscription_Plan3 varchar(55) DEFAULT NULL,
  Price3 double DEFAULT NULL,
  Company_url varchar(200) DEFAULT NULL,
  Image_url varchar(200) DEFAULT NULL,
  PhoneNumber varchar(55) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

CREATE TABLE UserSubscription (
  FullName varchar(55) DEFAULT NULL,
  Length varchar(55) DEFAULT NULL,
  Subscription_Plan varchar(55) DEFAULT NULL,
  Price double DEFAULT NULL,
  PhoneNumber varchar(55) DEFAULT NULL,
  StartDate varchar(55) DEFAULT NULL,
  EndDate varchar(55) DEFAULT NULL,
  Top_Subscription tinyint(1) DEFAULT NULL,
  IconUrl varchar(55) DEFAULT NULL,
  CreditCards varchar(100) DEFAULT NULL,
  ID int(11) NOT NULL AUTO_INCREMENT,
  Subscription_Name varchar(100) DEFAULT NULL,
  Subscription_Url varchar(100) DEFAULT NULL,
  deleteBool tinyint(1) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

CREATE TABLE Users (
  EmailID varchar(100) NOT NULL,
  Password varchar(100) DEFAULT NULL,
  PRIMARY KEY (EmailID)
) ;

