-- MySQL dump 10.13  Distrib 5.7.12, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TopSubscription`
--

DROP TABLE IF EXISTS `TopSubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TopSubscription` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Subscription_Name` varchar(55) DEFAULT NULL,
  `Subscription_length` varchar(55) DEFAULT NULL,
  `Subscription_Plan1` varchar(55) DEFAULT NULL,
  `Price1` double DEFAULT NULL,
  `Subscription_Plan2` varchar(55) DEFAULT NULL,
  `Price2` double DEFAULT NULL,
  `Subscription_Plan3` varchar(55) DEFAULT NULL,
  `Price3` double DEFAULT NULL,
  `Company_url` varchar(200) DEFAULT NULL,
  `Image_url` varchar(200) DEFAULT NULL,
  `PhoneNumber` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TopSubscription`
--

LOCK TABLES `TopSubscription` WRITE;
/*!40000 ALTER TABLE `TopSubscription` DISABLE KEYS */;
INSERT INTO `TopSubscription` VALUES (1,'Netflix','monthly','Basic',7.99,'Standard',9.99,'Premium',11.99,'https://www.netflix.com/','http://www.eonline.com/eol_images/Entire_Site/2014423/rs_560x415-140523111130-1024.netflix.jpg','1 (866) 579-7172 '),(2,'Spotify','monthly','Premium',9.99,'',0,'',0,'https://www.spotify.com/us/premium/?checkout=false','http://vignette4.wikia.nocookie.net/nocopyrightsounds/images/f/fe/Spotify-icon.jpg/revision/latest?cb=20151216175322','(917) 565-3894'),(3,'Amazon Prime','monthly','Plan 1(Monthly)',10.99,'Plan 2(Yearly)',99.99,'',0,'https://www.amazon.com/gp/help/customer/display.html?nodeId=200444160','http://www.websitemagazine.com/images/blog/amazon-icon.jpg','(866) 216-1072'),(4,'Pandora','monthly','Plan 1(Monthly)',4.99,'Plan 2(Yearly)',54.89,'',0,'http://help.pandora.com/customer/portal/articles/84834-pandora-one#4','https://cdn2.iconfinder.com/data/icons/metro-ui-dock/128/Pandora_alt.png','(510) 451-4100'),(5,'Music','monthly','Individual Membership',9.99,'Family Membership',14.99,'Student Membership',4.99,'http://www.apple.com/music/membership/','http://core0.staticworld.net/images/article/2015/07/apple-new-music-and-itunes-icon-100594577-orig.jpg','(408) 974-2042');
/*!40000 ALTER TABLE `TopSubscription` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-03  9:28:16
